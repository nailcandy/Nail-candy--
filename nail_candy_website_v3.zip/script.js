
// Basic demo form handler - replace with real backend integration when ready
document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      alert('Thanks! This demo form does not send messages. Copy the details and contact Victoria at 0530166046 or nailcandy755@gmail.com to complete booking.');
      form.reset();
    });
  }
});
