
Nail Candy — Website package
---------------------------
Files included:
- index.html
- styles.css
- script.js
- logo.svg

How to use:
1. Unzip the package and open index.html in your browser to preview.
2. Replace placeholder gallery images with your photos (edit the ".thumb" divs in index.html).
3. Hook the contact form to an email or booking API (e.g., Formspree, Netlify Forms, or your own backend).
4. To host: GitHub Pages, Netlify, or Vercel are easy free options. Upload the files and follow their guides.

If you'd like, I can:
- Convert this into a WordPress theme or Wix-ready assets.
- Add real gallery images and optimize for mobile.
- Integrate appointment booking (Calendly, Square, or custom form).
